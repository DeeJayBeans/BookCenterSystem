﻿Public Class Form1
    Dim currentItem As Integer = 1
    Dim invoicenum As Integer

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox2.Text = "" Or TextBox6.Text = "" Then
            MessageBox.Show("All fields must be filled")
        Else
            ListView1.Items.Add(TextBox1.Text)
            ListView1.Items(currentItem).SubItems.Add(TextBox2.Text)
            ListView1.Items(currentItem).SubItems.Add(TextBox3.Text)
            ListView1.Items(currentItem).SubItems.Add(TextBox4.Text)
            ListView1.Items(currentItem).SubItems.Add(TextBox5.Text)
            ListView1.Items(currentItem).SubItems.Add(TextBox6.Text)
            currentItem += 1
            Total = Total + Integer.Parse(TextBox6.Text)
            TotalItems += 1
            TextBox7.Text = TotalItems
            TextBox8.Text = "Php" & Total * 0.12
            TextBox9.Text = "Php" & Total * 0.88
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form3.Show()
    End Sub
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        If TextBox1.Text = "0001" Then
            TextBox2.Text = Form2.ListView2.Items(0).SubItems(1).Text
            TextBox3.Text = Form2.ListView2.Items(0).SubItems(2).Text
            TextBox4.Text = Form2.ListView2.Items(0).SubItems(3).Text
        ElseIf TextBox1.Text = "0002" Then
            TextBox2.Text = Form2.ListView2.Items(1).SubItems(1).Text
            TextBox3.Text = Form2.ListView2.Items(1).SubItems(2).Text
            TextBox4.Text = Form2.ListView2.Items(1).SubItems(3).Text
        ElseIf TextBox1.Text = "0003" Then
            TextBox2.Text = Form2.ListView2.Items(2).SubItems(1).Text
            TextBox3.Text = Form2.ListView2.Items(2).SubItems(2).Text
            TextBox4.Text = Form2.ListView2.Items(2).SubItems(3).Text
        ElseIf TextBox1.Text = "0004" Then
            TextBox2.Text = Form2.ListView2.Items(3).SubItems(1).Text
            TextBox3.Text = Form2.ListView2.Items(3).SubItems(2).Text
            TextBox4.Text = Form2.ListView2.Items(3).SubItems(3).Text
        Else
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
        End If
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged
        If Not (TextBox5.Text = "") Then
            TextBox6.Text = Integer.Parse(TextBox4.Text) * Integer.Parse(TextBox5.Text)
        Else
            TextBox6.Text = ""
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox1.Clear()
        TextBox5.Clear()
        ListView1.Clear()
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()
        TextBox10.Clear()
        Button3.Enabled = False
        Button2.Enabled = True
        Label6.Text = "000" & Label6.Text + 1
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form2.Show()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Form4.Show()
    End Sub
End Class
