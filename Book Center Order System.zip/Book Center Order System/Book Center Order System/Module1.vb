﻿Module Module1
    Public paid As Boolean = False
    Public Total As Double
    Public TotalItems As Integer
    Public invoicenum As Long
End Module
