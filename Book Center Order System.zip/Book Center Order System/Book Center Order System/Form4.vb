﻿Public Class Form4
    Dim currentItem As Integer = 1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MessageBox.Show("All fields must be filled")
        Else
            ListView1.Items.Add(TextBox1.Text)
            ListView1.Items(currentItem).SubItems.Add(TextBox2.Text)
            ListView1.Items(currentItem).SubItems.Add(TextBox3.Text)
            currentItem += 1
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If (ComboBox1.Text = "Ascending") Then
            ListView1.Sorting = SortOrder.Ascending
        ElseIf (ComboBox1.Text = "Descending") Then
            ListView1.Sorting = SortOrder.Descending
        End If
    End Sub
End Class