﻿Public Class Form3
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim amounttendered As Double
        amounttendered = Integer.Parse(TextBox1.Text)
        If (amounttendered + 1 <= Total) Then
            MessageBox.Show("Insufficient Funds")
            Form1.Button2.Enabled = True
        Else
            MessageBox.Show("Change is Php " & (amounttendered - Total))
            Form1.Button3.Enabled = True
            Form1.Button2.Enabled = False
            Me.Close()

        End If

    End Sub
End Class