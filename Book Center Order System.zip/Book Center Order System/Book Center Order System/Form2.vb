﻿Public Class Form2
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If (ComboBox1.Text = "Ascending") Then
            ListView2.Sorting = SortOrder.Ascending
        ElseIf (ComboBox1.Text = "Descending") Then
            ListView2.Sorting = SortOrder.Descending
        End If
    End Sub
End Class